pytest_plugins = 'setuptools.tests.fixtures'
